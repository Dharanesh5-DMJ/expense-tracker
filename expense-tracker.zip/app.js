let expenses = JSON.parse(localStorage.getItem('expenses')) || [];

function render() {
let list = document.getElementById('list');
let total = 0;
list.innerHTML = '';

expenses.forEach((exp, index) => {
total += Number(exp.amount);
list.innerHTML += `<li>${exp.desc} - ₹${exp.amount} <button onclick="removeExpense(${index})">X</button></li>`;
});

document.getElementById('total').innerText = total;
localStorage.setItem('expenses', JSON.stringify(expenses));
}

function addExpense() {
let desc = document.getElementById('desc').value;
let amount = document.getElementById('amount').value;

if (!desc || !amount) return;

expenses.push({ desc, amount });
render();

document.getElementById('desc').value = '';
document.getElementById('amount').value = '';
}

function removeExpense(index) {
expenses.splice(index, 1);
render();
}

render();
